from django.test import TestCase
import pymongo

if __name__ =="__main__":
    # con1 = pymongo.MongoClient("192.168.68.11", 20000)
    # con2 = pymongo.MongoClient("localhost", 27017)
    #
    # col1 = con1.divorceCase.searchPerform
    # col2 = con2.divorceCase.searchPerform
    #
    # for item in col1.find():
    #     col2.insert(item)

    print(1/2)
    print(int((0.1-0.00001)*10)%10)

    print([0 for i in range(10)])